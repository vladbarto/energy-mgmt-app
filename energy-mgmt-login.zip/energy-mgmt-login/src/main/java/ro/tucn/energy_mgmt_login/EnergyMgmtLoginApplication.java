package ro.tucn.energy_mgmt_login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyMgmtLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyMgmtLoginApplication.class, args);
	}

}
