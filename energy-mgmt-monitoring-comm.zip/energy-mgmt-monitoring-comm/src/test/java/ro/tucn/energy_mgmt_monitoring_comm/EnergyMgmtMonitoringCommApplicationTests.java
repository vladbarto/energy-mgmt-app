package ro.tucn.energy_mgmt_monitoring_comm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyMgmtMonitoringCommApplicationTests {

	@Test
	void contextLoads() {
	}

}
