package ro.tucn.energy_mgmt_monitoring_comm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyMgmtMonitoringCommApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyMgmtMonitoringCommApplication.class, args);
	}

}
